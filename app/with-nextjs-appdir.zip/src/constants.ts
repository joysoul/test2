export const API_URL = "https://api.fake-rest.refine.dev";
